<?php

namespace App\Models;

use CodeIgniter\Model;

class DataUser extends Model
{
    protected $table = "users";
    protected $primaryKey = "id";
}
