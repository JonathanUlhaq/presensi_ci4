<?php

namespace Config;

use CodeIgniter\Config\ForeignCharacters as BaseForeignCharacters;

class ForeignCharacters extends BaseForeignCharacters
{
}
